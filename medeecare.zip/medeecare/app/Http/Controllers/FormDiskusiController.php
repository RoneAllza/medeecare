<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FormDiskusiController extends Controller
{
    public function viewForm(){
       return view ('formdiskusikesehatan');
   }
   
} 
