<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class infopenyakitController extends Controller
{
    //
}
