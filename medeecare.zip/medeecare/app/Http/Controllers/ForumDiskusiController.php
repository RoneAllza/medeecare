<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ForumDiskusiController extends Controller
{
    public function viewForum(){
        return view ('forumdiskusikesehatan');
    }

}
