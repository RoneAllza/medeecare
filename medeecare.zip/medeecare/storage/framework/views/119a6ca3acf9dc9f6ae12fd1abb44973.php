
<?php $__env->startSection('content'); ?>
<!-- section -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <div class="col-md-12">
                <div class="section-title">
                    <h2>List of Doctors</h2>
                </div>
            </div>
            <!-- List of Doctors -->
            <?php $__currentLoopData = $dokter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="doctor-entry text-center">
                    <div class="doctor-img">
                        <img src="<?php echo e(asset('uploads/'.$doc->gambar)); ?>" alt="<?php echo e($doc->dokter); ?>" height="200px" width="200px">
                    </div>
                    <div class="doctor-info">
                        <h3><?php echo e($doc->dokter); ?></h3>
                        <p><?php echo e($doc->body); ?></p> <!-- Changed from $doc->Deskripsi to $doc->body to match database fields -->
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- /List of Doctors -->
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.appMental', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\documents\Medeecare\medeecare\resources\views/kesehatanmental.blade.php ENDPATH**/ ?>